/*
 * File name :  main.js
 * Author : 
 * version : 1.0
 * Date : 2006/11/01
 */

/**
 *	TabUI initialization
 */
/* ---- 20240731 add ---- */
var tabPages;
/* ---- ------------ ---- */
function initTab() {
    document.addEventListener('DOMContentLoaded', function () {
        var allTabPanes = document.querySelectorAll('.tab-pane');
        var activeTabPane = document.querySelector('.tab-pane.show.active');
        
        allTabPanes.forEach(function (pane) {
            if (!pane.classList.contains('show')) {
                pane.classList.add('d-none');
            }
        });

        activeTabPane.classList.remove('d-none');

        var tabLinks = document.querySelectorAll('.nav-link');
        tabLinks.forEach(function (link) {
            link.addEventListener('shown.bs.tab', function (event) {
                var targetPane = document.querySelector(event.target.getAttribute('href'));
                allTabPanes.forEach(function (pane) {
                    pane.classList.add('d-none');
                });
                targetPane.classList.remove('d-none');
            });
        });
    });
}

/**
 *	The Tab which corresponds to the index of the TabUI activation index 0,1,2...
 */
function tabItemSelect(index) {
	/* ---- 20240731 add ---- */
	tabPages = document.querySelectorAll('.tab-pane');
	// console.log('!!!====---tabPages = '+tabPages);
	/* ---- ------------ ---- */
	for (var i=0; i<tabItems.length; i++) {
		/* The tabItems not to be and the display false report 
		   (the disappearTab () with this one case of security when the appearTab () controlling, not to peel in order not to be visible)
		*/
		if (tabItems[i].style.display != "none" ) {
			tabItems[i].style.display = "inline";	
			tabItems[i].style.backgroundColor = 'transparent';
			/* ---- 20240731 change selector ---- */
			tabPages[i].classList.remove('active');
			/* ---- ------------------------ ---- */
		}
	}
	tabItems[index].style.backgroundColor = 'transparent';
	/* ---- 20240731 change selector ---- */
	tabPages[index].classList.add('active');
	/* ---- ------------------------ ---- */
}

/**
 * tab portion of TabUI this description below of security
 */
function disappearTab(tabidx) {
	/* ---- 20240802 add ---- */
	tabPages = document.querySelectorAll('.tab-pane');
	/* ---- ------------ ---- */
	if(isArray(tabidx)) {
		for (var i=0; i<tabidx.length; i++) {
			console.log('!!!!---tabidx_if = '+tabPages[tabidx[i]]);
			/* ---- 20240802 change ----*/
			tabItems[tabidx[i]].parentElement.parentElement.style.display = "none";
			// tabPages[tabidx[i]].style.display = "none";				
			/* ---- ------------- ---- */			
		}
	} else {
		console.log('!!!!---tabidx_else = '+tabPages[tabidx]);
		/* ---- 20240802 change ----*/
		tabItems[tabidx].parentElement.parentElement.style.display = "none";
		// tabPages[tabidx].style.display = "none";
		/* ---- ------------- ---- */		
	}	
}

/** 
 * It does to show the tab portion of the TabUI
 */
function appearTab(tabidx) {
	/* ---- 20240802 add ---- */
	tabPages = document.querySelectorAll('.tab-pane');
	/* ---- ------------ ---- */
	if(isArray(tabidx)) {
		for (var i=0; i<tabidx.length; i++) {
			/* ---- 20240802 change ----*/
			tabItems[tabidx[i]].parentElement.parentElement.style.display = "block";
			tabPages[tabidx[i]].style.display = "block";
			/* ---- ------------- ---- */
		}
	} else {
		/* ---- 20240802 change ----*/
		tabItems[tabidx].parentElement.parentElement.style.display = "block";
		tabPages[tabidx].style.display = "block";
		/* ---- ------------- ---- */
	}	
}


/**
 *	When the mouse cursor is located above the Tab of the TabUI, the letter color change
 */
function tabItemMouseOver(index) {
	if (tabItems[index].style.backgroundColor != COLOR_TAB_SELECTED_BG) {
		tabItems[index].style.color = COLOR_TAB_MOUSEOVER;
	}
}

/**
 *	When the mouse escapes from the Tab of the TabUI, the letter color change
 */
function tabItemMouseOut(index) {
	tabItems[index].style.color = COLOR_TAB_MOUSEOUT;
}

/**
 *	Currently the Index of the Tab which is activated returning
 */
function getSelectedTab() {
	var obj = document.querySelectorAll('#tabItems');
	if (obj) {
		for (var i=0; i<obj.length; i++) {
			if (obj[i].style.backgroundColor == COLOR_TAB_SELECTED_BG) return i;
		}
	}
	return -1;
}

/**
 *	Previously Tab TabUI activation
 */
function moveFocusLeft() {
	var index = getSelectedTab();
	if (index == -1) return;
	if (--index >= 0) tabItemSelect(index);
}

/**
 *	Next Tab of TabUI activation
 */
function moveFocusRight() {
	var index = getSelectedTab();
	if (index == -1) return;
	if (++index < tabItems.length) tabItemSelect(index);
}

/**
 *	It searches the index of the tab, return
 */
function searchTab(tab) {
	/* ---- 20240731 change selector ---- */
	var tabPages = document.querySelectorAll('.tab-pane');
	/* ---- ------------------------ ---- */
	if (!tabPages) return -1;
	for (var i=0; i<tabPages.length; i++) {
		if (tabPages[i] == tab) return i;
	}
	return -1;
}